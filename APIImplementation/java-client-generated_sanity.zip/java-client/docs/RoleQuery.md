
# RoleQuery

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**text** | **String** |  |  [optional]
**level** | **Integer** |  |  [optional]




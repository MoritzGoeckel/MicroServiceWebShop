
# ProductQuery

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**text** | **String** |  |  [optional]
**priceMin** | **Double** |  |  [optional]
**priceMax** | **Double** |  |  [optional]
**category** | **Long** |  |  [optional]




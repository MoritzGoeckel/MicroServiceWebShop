
# UserQuery

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **String** |  |  [optional]
**text** | **String** |  |  [optional]
**role** | **Long** |  |  [optional]



